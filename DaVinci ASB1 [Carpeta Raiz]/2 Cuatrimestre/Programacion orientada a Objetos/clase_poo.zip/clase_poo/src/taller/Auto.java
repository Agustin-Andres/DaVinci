package taller;



public class Auto extends Vehiculo{

    int cantidadPuertas;

    public Auto(int id, String patente, String marca, String modelo, String color, int cantidadPuertas){
        super(id, patente, marca, modelo, color);
        this.cantidadPuertas = cantidadPuertas;
    }
    // SETTER
    public void setCantidadPuertas(int cantidadPuertas){
        this.cantidadPuertas = cantidadPuertas;
    }

    //GETTER
    public int getCantidadPuertas(){
        return cantidadPuertas;
    }
}
