package taller;

public class Vehiculo {

    int id;
    String patente;
    String marca;
    String modelo;
    String color;

    public Vehiculo(){}

    public Vehiculo(int id, String patente, String marca, String modelo, String color){
        this.id = id;
        this.patente = patente.trim();
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    // SETTER
    public void setId(int id){
        this.id = id;
    }    
    public void setPatente(String patente){
        this.patente = patente;
    }  
    public void setMarca(String marca){
        this.marca = marca;
    }  
    public void setModelo(String modelo){
        this.modelo = modelo;
    }  
    public void setColor(String color){
        this.color = color;
    }

    //GETTER
    public int getId(){
        return id;
    }
    public String getPatente(){
        return patente;
    }
    public String getMarca(){
        return marca;
    }
    public String getModelo(){
        return modelo;
    }
    public String getColor(){
        return color;
    }

    

    //modificador de acceso, tipo de retorno, nombre
    public void arrancar(){}

}
