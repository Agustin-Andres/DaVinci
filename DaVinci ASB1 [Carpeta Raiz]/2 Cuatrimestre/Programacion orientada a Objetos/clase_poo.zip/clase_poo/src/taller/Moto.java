package taller;

public class Moto extends Vehiculo{

    public String tipoManubrio;

}
