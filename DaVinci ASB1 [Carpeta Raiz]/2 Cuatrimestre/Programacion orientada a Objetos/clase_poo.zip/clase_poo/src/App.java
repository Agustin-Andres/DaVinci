import taller.Auto;

public class App {
    public static void main(String[] args) throws Exception {
        //System.out.println("Hello, World!");

        Auto nuevoAuto = new Auto(1, "ABC123", "Ford", "Fiesta", "Rojo", 5);

        System.out.println("El auto: " + nuevoAuto.getId() + " tiene " + nuevoAuto.getCantidadPuertas() + " puertas" );

        Auto auto2 = new Auto(0,null,null,null,null, 0);
        auto2.setId(2);

        auto2.setCantidadPuertas(100);



    }
}
