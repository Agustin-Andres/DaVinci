
import Interfaz.Interfaz;

public class Liberia {
    public static void main(String[] args) throws Exception {
        Interfaz.menuInicial();
    }
}
