-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema P2_Avellaneda
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema P2_Avellaneda
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `P2_Avellaneda` DEFAULT CHARACTER SET utf8 ;
USE `P2_Avellaneda` ;

-- -----------------------------------------------------
-- Table `P2_Avellaneda`.`continente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `P2_Avellaneda`.`continente` (
  `id_continente` INT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`id_continente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `P2_Avellaneda`.`pais`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `P2_Avellaneda`.`pais` (
  `id_pais` INT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(60) NOT NULL,
  `id_continente` INT NOT NULL,
  PRIMARY KEY (`id_pais`),
  INDEX `fk_pais_continente1_idx` (`id_continente` ASC) ,
  CONSTRAINT `fk_pais_continente1`
    FOREIGN KEY (`id_continente`)
    REFERENCES `P2_Avellaneda`.`continente` (`id_continente`)
   )
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `P2_Avellaneda`.`poblacion_inflacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `P2_Avellaneda`.`poblacion_inflacion` (
  `id_poblacion_inflacion` INT NOT NULL AUTO_INCREMENT,
  `mes` INT NOT NULL,
  `anio` INT NOT NULL,
  `poblacion` INT(12) NOT NULL,
  `porcentaje_inflacion` DOUBLE(5,2) NOT NULL,
  `id_pais` INT NOT NULL,
  PRIMARY KEY (`id_poblacion_inflacion`),
  INDEX `fk_poblacion_inflacion_pais1_idx` (`id_pais` ASC) ,
  CONSTRAINT `fk_poblacion_inflacion_pais1`
    FOREIGN KEY (`id_pais`)
    REFERENCES `P2_Avellaneda`.`pais` (`id_pais`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `P2_Avellaneda`.`continente`
-- -----------------------------------------------------
START TRANSACTION;
USE `P2_Avellaneda`;
INSERT INTO `P2_Avellaneda`.`continente` (`id_continente`, `nombre`) VALUES (1, 'Asia');
INSERT INTO `P2_Avellaneda`.`continente` (`id_continente`, `nombre`) VALUES (2, 'America');
INSERT INTO `P2_Avellaneda`.`continente` (`id_continente`, `nombre`) VALUES (3, 'Africa');
INSERT INTO `P2_Avellaneda`.`continente` (`id_continente`, `nombre`) VALUES (4, 'Antartida');
INSERT INTO `P2_Avellaneda`.`continente` (`id_continente`, `nombre`) VALUES (5, 'Europa');
INSERT INTO `P2_Avellaneda`.`continente` (`id_continente`, `nombre`) VALUES (6, 'Oceania');

COMMIT;


-- -----------------------------------------------------
-- Data for table `P2_Avellaneda`.`pais`
-- -----------------------------------------------------
START TRANSACTION;
USE `P2_Avellaneda`;
INSERT INTO `P2_Avellaneda`.`pais` (`id_pais`, `nombre`, `id_continente`) VALUES (1, 'Argentina', 2);
INSERT INTO `P2_Avellaneda`.`pais` (`id_pais`, `nombre`, `id_continente`) VALUES (2, 'Francia', 5);
INSERT INTO `P2_Avellaneda`.`pais` (`id_pais`, `nombre`, `id_continente`) VALUES (3, 'Nueva Zelanda', 6);
INSERT INTO `P2_Avellaneda`.`pais` (`id_pais`, `nombre`, `id_continente`) VALUES (4, 'Japon', 1);
INSERT INTO `P2_Avellaneda`.`pais` (`id_pais`, `nombre`, `id_continente`) VALUES (5, 'Nigeria', 3);

COMMIT;


-- -----------------------------------------------------
-- Data for table `P2_Avellaneda`.`poblacion_inflacion`
-- -----------------------------------------------------
START TRANSACTION;
USE `P2_Avellaneda`;
INSERT INTO `P2_Avellaneda`.`poblacion_inflacion` (`id_poblacion_inflacion`, `mes`, `anio`, `poblacion`, `porcentaje_inflacion`, `id_pais`) VALUES (1, 1, 2024, 45376763, 52.43, 1);
INSERT INTO `P2_Avellaneda`.`poblacion_inflacion` (`id_poblacion_inflacion`, `mes`, `anio`, `poblacion`, `porcentaje_inflacion`, `id_pais`) VALUES (2, 6, 2023, 67012883, 5.28, 2);
INSERT INTO `P2_Avellaneda`.`poblacion_inflacion` (`id_poblacion_inflacion`, `mes`, `anio`, `poblacion`, `porcentaje_inflacion`, `id_pais`) VALUES (3, 7, 2022, 5116411, 3.17, 3);
INSERT INTO `P2_Avellaneda`.`poblacion_inflacion` (`id_poblacion_inflacion`, `mes`, `anio`, `poblacion`, `porcentaje_inflacion`, `id_pais`) VALUES (4, 2, 2024, 125845653, 0.98, 4);
INSERT INTO `P2_Avellaneda`.`poblacion_inflacion` (`id_poblacion_inflacion`, `mes`, `anio`, `poblacion`, `porcentaje_inflacion`, `id_pais`) VALUES (5, 9, 2023, 206139589, 18.76, 5);

COMMIT;



-- -----------------------------------------------------
-- Queries para las consultas de la consigna
-- -----------------------------------------------------
SELECT * FROM continente;
SELECT * FROM pais;
SELECT * FROM poblacion_inflacion;

SELECT * FROM continente WHERE nombre LIKE '%r%'ORDER BY nombre ASC;

SELECT COUNT(*) AS cantidad_paises FROM pais WHERE id_pais > 2;

SELECT * FROM poblacion_inflacion JOIN pais ON poblacion_inflacion.id_pais = pais.id_pais  JOIN continente on pais.id_continente = continente.id_continente;

SELECT COUNT(*) AS cantidad_meses FROM poblacion_inflacion JOIN pais ON poblacion_inflacion.id_pais = pais.id_pais JOIN continente on pais.id_continente = continente.id_continente
WHERE poblacion_inflacion.poblacion > 1000000 AND continente.nombre LIKE '%r%';

