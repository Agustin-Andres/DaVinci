-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema TP2_G4
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `TP2_G4` ;

-- -----------------------------------------------------
-- Schema TP2_G4
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `TP2_G4` DEFAULT CHARACTER SET utf8 ;
USE `TP2_G4` ;

-- -----------------------------------------------------
-- Table `pasajero`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `pasajero` ;

CREATE TABLE IF NOT EXISTS `pasajero` (
  `id_pasajero` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `DNI` VARCHAR(45) NOT NULL,
  `telefono` VARCHAR(45) NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_pasajero`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `vehiculo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `vehiculo` ;

CREATE TABLE IF NOT EXISTS `vehiculo` (
  `id_vehiculo` INT NOT NULL AUTO_INCREMENT,
  `modelo` VARCHAR(45) NOT NULL,
  `marca` VARCHAR(45) NOT NULL,
  `anio` INT NOT NULL,
  `patente` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_vehiculo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `conductor`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `conductor` ;

CREATE TABLE IF NOT EXISTS `conductor` (
  `id_conductor` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `apellido` VARCHAR(45) NOT NULL,
  `DNI` VARCHAR(45) NOT NULL,
  `telefono` VARCHAR(45) NOT NULL,
  `correo` VARCHAR(45) NOT NULL,
  `calificacion_promedio` FLOAT NOT NULL,
  `id_vehiculo` INT NOT NULL,
  PRIMARY KEY (`id_conductor`),
  CONSTRAINT `fk_conductor_vehiculo1`
    FOREIGN KEY (`id_vehiculo`)
    REFERENCES `vehiculo` (`id_vehiculo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `origen`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `origen` ;

CREATE TABLE IF NOT EXISTS `origen` (
  `id_origen` INT NOT NULL AUTO_INCREMENT,
  `direccion` VARCHAR(45) NOT NULL,
  `codigo_postal` VARCHAR(45) NOT NULL,
  `ciudad` VARCHAR(45) NOT NULL,
  `pais` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_origen`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `tipo_transporte`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tipo_transporte` ;

CREATE TABLE IF NOT EXISTS `tipo_transporte` (
  `id_tipo_transporte` INT NOT NULL AUTO_INCREMENT,
  `descripcion` VARCHAR(1000) NOT NULL,
  PRIMARY KEY (`id_tipo_transporte`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `traslado`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `traslado` ;

CREATE TABLE IF NOT EXISTS `traslado` (
  `id_traslado` INT NOT NULL AUTO_INCREMENT,
  `hora_pedido` DATETIME NOT NULL,
  `hora_confirmacion` DATETIME NOT NULL,
  `hora_salida` DATETIME NOT NULL,
  `hora_llegada` DATETIME NOT NULL,
  `id_vehiculo` INT NOT NULL,
  `id_origen` INT NOT NULL,
  `id_pasajero` INT NOT NULL,
  `id_conductor` INT NOT NULL,
  `id_tipo_transporte` INT NOT NULL,
  PRIMARY KEY (`id_traslado`),
  CONSTRAINT `fk_traslado_pasajero`
    FOREIGN KEY (`id_pasajero`)
    REFERENCES `pasajero` (`id_pasajero`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_traslado_conductor`
    FOREIGN KEY (`id_conductor`)
    REFERENCES `conductor` (`id_conductor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_traslado_vehiculo1`
    FOREIGN KEY (`id_vehiculo`)
    REFERENCES `vehiculo` (`id_vehiculo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_traslado_origen1`
    FOREIGN KEY (`id_origen`)
    REFERENCES `origen` (`id_origen`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_traslado_tipo_transporte1`
    FOREIGN KEY (`id_tipo_transporte`)
    REFERENCES `tipo_transporte` (`id_tipo_transporte`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `calificacion`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `calificacion` ;

CREATE TABLE IF NOT EXISTS `calificacion` (
  `id_calificacion` INT NOT NULL AUTO_INCREMENT,
  `calificacion_conductor` DECIMAL(2,1) NOT NULL,
  `calificacion_viaje` DECIMAL(2,1) NOT NULL,
  `id_traslado` INT NOT NULL,
  PRIMARY KEY (`id_calificacion`),
  CONSTRAINT `fk_calificacion_traslado`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `traslado` (`id_traslado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `problema`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `problema` ;

CREATE TABLE IF NOT EXISTS `problema` (
  `id_problema` INT NOT NULL AUTO_INCREMENT,
  `descripcion` VARCHAR(100) NOT NULL,
  `resuelto` TINYINT NOT NULL,
  `id_traslado` INT NOT NULL,
  PRIMARY KEY (`id_problema`),
  CONSTRAINT `fk_problema_traslado`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `traslado` (`id_traslado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ubicacion`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ubicacion` ;

CREATE TABLE IF NOT EXISTS `ubicacion` (
  `id_ubicacion` INT NOT NULL AUTO_INCREMENT,
  `latitud` DECIMAL(6,4) NOT NULL,
  `longitud` DECIMAL(6,4) NOT NULL,
  `timestamp` DATETIME NOT NULL,
  `id_traslado` INT NOT NULL,
  `id_pasajero` INT NOT NULL,
  PRIMARY KEY (`id_ubicacion`),
  CONSTRAINT `fk_ubicacion_traslado`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `traslado` (`id_traslado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_id_pasajero`
    FOREIGN KEY (`id_pasajero`)
    REFERENCES `pasajero` (`id_pasajero`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ubicacion_vehiculo`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `vehiculo` (`id_vehiculo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `destino`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `destino` ;

CREATE TABLE IF NOT EXISTS `destino` (
  `id_destino` INT NOT NULL AUTO_INCREMENT,
  `direccion` VARCHAR(45) NOT NULL,
  `codigo_postal` VARCHAR(45) NOT NULL,
  `ciudad` VARCHAR(45) NOT NULL,
  `pais` VARCHAR(45) NOT NULL,
  `multidestino` TINYINT NOT NULL,
  `id_traslado` INT NOT NULL,
  PRIMARY KEY (`id_destino`),
  CONSTRAINT `fk_destino_traslado`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `traslado` (`id_traslado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pago`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `pago` ;

CREATE TABLE IF NOT EXISTS `pago` (
  `id_pago` INT NOT NULL AUTO_INCREMENT,
  `metodo` VARCHAR(45) NOT NULL,
  `monto` DECIMAL(10,2) NOT NULL,
  `id_pasajero` INT NOT NULL,
  `id_traslado` INT NOT NULL,
  PRIMARY KEY (`id_pago`),
  CONSTRAINT `fk_pago_pasajero1`
    FOREIGN KEY (`id_pasajero`)
    REFERENCES `pasajero` (`id_pasajero`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_pago_traslado1`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `traslado` (`id_traslado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `costo_adicional`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `costo_adicional` ;

CREATE TABLE IF NOT EXISTS `costo_adicional` (
  `id_costo_adicional` INT NOT NULL AUTO_INCREMENT,
  `costo` DECIMAL(12,3) NOT NULL,
  `especificacion` VARCHAR(45) NOT NULL,
  `id_pago` INT NOT NULL,
  PRIMARY KEY (`id_costo_adicional`),
  CONSTRAINT `fk_costo_adicional_pago1`
    FOREIGN KEY (`id_pago`)
    REFERENCES `pago` (`id_pago`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `peaje`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `peaje` ;

CREATE TABLE IF NOT EXISTS `peaje` (
  `id_peaje` INT NOT NULL AUTO_INCREMENT,
  `costo` DECIMAL(10,2) NOT NULL,
  `id_traslado` INT NOT NULL,
  PRIMARY KEY (`id_peaje`),
  CONSTRAINT `fk_peaje_traslado1`
    FOREIGN KEY (`id_traslado`)
    REFERENCES `traslado` (`id_traslado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `pais`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `pais` ;

CREATE TABLE IF NOT EXISTS `pais` (
  `id_pais` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `capital` VARCHAR(45) NOT NULL,
  `zona_horaria` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_pais`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ciudad`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ciudad` ;

CREATE TABLE IF NOT EXISTS `ciudad` (
  `id_ciudad` INT NOT NULL AUTO_INCREMENT,
  `nombre_ciudad` VARCHAR(100) NOT NULL,
  `partido_localidad` VARCHAR(100) NOT NULL,
  `id_pais` INT NOT NULL,
  PRIMARY KEY (`id_ciudad`),
  CONSTRAINT `fk_ciudad_pais`
    FOREIGN KEY (`id_pais`)
    REFERENCES `pais` (`id_pais`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `direccion_pasajero`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `direccion_pasajero` ;

CREATE TABLE IF NOT EXISTS `direccion_pasajero` (
  `id_direccion_pasajero` INT NOT NULL AUTO_INCREMENT,
  `barrio` VARCHAR(45) NOT NULL,
  `calle` VARCHAR(45) NOT NULL,
  `numero` VARCHAR(45) NOT NULL,
  `piso_depto` VARCHAR(45) NULL,
  `id_pasajero` INT NOT NULL,
  `id_ciudad` INT NOT NULL,
  PRIMARY KEY (`id_direccion_pasajero`),
  CONSTRAINT `fk_direccion_pasajero_pasajero1`
    FOREIGN KEY (`id_pasajero`)
    REFERENCES `pasajero` (`id_pasajero`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_direccion_pasajero_ciudad1`
    FOREIGN KEY (`id_ciudad`)
    REFERENCES `ciudad` (`id_ciudad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ubicacion_ vehiculo`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ubicacion_ vehiculo` ;

CREATE TABLE IF NOT EXISTS `ubicacion_ vehiculo` (
  `id_ubicacion_ vehiculo` INT NOT NULL AUTO_INCREMENT,
  `latitud` DECIMAL(6,4) NOT NULL,
  `longitud` DECIMAL(6,4) NOT NULL,
  `timestamp` DATETIME NOT NULL,
  `id_vehiculo` INT NOT NULL,
  PRIMARY KEY (`id_ubicacion_ vehiculo`),
  CONSTRAINT `FK_ubicacion_vehiculo_vehiculo`
    FOREIGN KEY (`id_vehiculo`)
    REFERENCES `vehiculo` (`id_vehiculo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- -----------------------------------------------------
-- Data for table `pasajero`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (1, 'Carlos', 'Perez', '34852369', '11 67890123', 'clopez25@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (2, 'Ramona', 'Castro', '25789741', '11 87651234', 'ramo_03@yahoo.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (3, 'Julio', 'Mendez', '34842596', '1177858833', 'juliomen@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (4, 'Laura', 'Robles', '29789456', '1132748503', 'lau8522@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (5, 'Mateo', 'Mascherano', '27852147', '1147329920', 'masche@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (6, 'Sabrina', 'Illia', '33147852', '351 6789012', 'sailli@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (7, 'Lucia', 'Martinez', '36852147', '351 6789012', 'lumarti@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (8, 'Matias', 'Kranevitter', '29490555', '1122557700', 'matikrak@yahoo.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (9, 'Lucas', 'Carmona', '24852369', '1125870000', 'cucarmo@gmail.com');
INSERT INTO `pasajero` (`id_pasajero`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`) VALUES (10, 'Guillermina', 'Siciliani', '32654785', '1152007700', 'guillesick@gmail.com');

COMMIT;


-- -----------------------------------------------------
-- Data for table `vehiculo`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (1, 'Corolla', 'Toyota', 2020, 'ABC1234');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (2, 'Gol', 'Volkswagen', 2019, 'XY 5678');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (3, 'Focus', 'Ford', 2018, 'JKL3456');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (4, '308', 'Peugeot', 2020, 'MNP 9876');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (5, 'Clio', 'Renault', 2020, 'PQR6543');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (6, 'Civic', 'Honda', 2021, 'STU4321');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (7, 'Sandero', 'Renault', 2023, 'VWX1234');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (8, 'Cruze', 'Chevrolet', 2019, 'BCD5678');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (9, 'Figo', 'Ford', 2017, 'EFH3456');
INSERT INTO `vehiculo` (`id_vehiculo`, `modelo`, `marca`, `anio`, `patente`) VALUES (10, '208', 'Peugeot', 2018, 'GHI7890');

COMMIT;


-- -----------------------------------------------------
-- Data for table `conductor`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (1, 'Julio', 'Drago', '23852963', '3519012347', 'dragonju@gmail.com', 4.0, 1);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (2, 'Rafael', 'Zurita', '33652741', '1112345678', 'rafazu@gmail.com', 4.2, 2);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (3, 'Renee', 'Andrade', '21854963', '1123456700', 'andrade_rene@gmail.com', 4.3, 3);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (4, 'Carlos', 'Meneses', '22851742', '1185207700', 'calonmene@gmail.com', 4.4, 4);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (5, 'Luis', 'Gonzales', '25963147', '3515678003', 'luisitogon@gmail.com', 4.5, 5);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (6, 'Gimena', 'Ruiz', '32685004', '1156789012', 'likgime@gmai.com', 4.0, 6);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (7, 'Claudio', 'Menentiel', '31852336', '1112346787', 'menen10@gmail.com', 4.0, 7);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (8, 'Agustina', 'Barroso', '19094852', '1112346789', 'agus_taxi@gmail.com', 4.0, 8);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (9, 'Pedro', 'Cano', '30741225', '1145678901', 'canito_10@gmail.com', 4.0, 9);
INSERT INTO `conductor` (`id_conductor`, `nombre`, `apellido`, `DNI`, `telefono`, `correo`, `calificacion_promedio`, `id_vehiculo`) VALUES (10, 'Carmen', 'Yepez', '20887224', '3518901236', 'carmencita_y@gmail.com', 4.6, 10);

COMMIT;


-- -----------------------------------------------------
-- Data for table `origen`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (1, 'Calle de Mayo 2455', '1416', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (2, 'Avenida de Mayo 1250', '1064', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (3, 'Calle Corrientes 245', '1043', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (4, 'Avenida 9 de Julio 5000,', '3314', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (5, 'Calle Cabildo 1350', '2174', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (6, 'Calle Libertador 8900', '1429', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (7, 'Avenida Pueyrredón 3000', '0145', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (8, 'Calle Scalabrini Ortiz 3100', '2317', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (9, 'Calle Santa Fe 3700', '1152', 'CABA', 'Argentina');
INSERT INTO `origen` (`id_origen`, `direccion`, `codigo_postal`, `ciudad`, `pais`) VALUES (10, 'L Lucila 2020', '2630', 'CABA', 'Argentina');

COMMIT;


-- -----------------------------------------------------
-- Data for table `tipo_transporte`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `tipo_transporte` (`id_tipo_transporte`, `descripcion`) VALUES (1, 'envios_encomiendas');
INSERT INTO `tipo_transporte` (`id_tipo_transporte`, `descripcion`) VALUES (2, 'pasajeros');
INSERT INTO `tipo_transporte` (`id_tipo_transporte`, `descripcion`) VALUES (3, 'mascotas');

COMMIT;


-- -----------------------------------------------------
-- Data for table `traslado`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (1, '2024-01-15 08:30:00', '2024-01-15 08:35:00', '2024-01-15 08:38:00', '2024-01-15 09:38:00', 1, 1, 10, 1, 1);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (2, '2024-02-20 14:45:30', '2024-02-20 14:50:30', '2024-02-20 14:53:30', '2024-02-20 15:53:30', 2, 2, 9, 2, 2);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (3, '2024-03-05 19:00:00', '2024-03-05 19:15:00', '2024-03-05 19:08:00', '2024-03-05 20:08:00', 3, 3, 8, 3, 2);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (4, '2024-04-10 12:15:45', '2024-04-10 12:20:45', '2024-04-10 12:23:45', '2024-04-10 13:53:45', 4, 4, 7, 4, 2);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (5, '2024-05-18 16:30:00', '2024-05-18 16:37:00', '2024-05-18 16:38:00', '2024-05-18 17:38:00', 5, 5, 5, 5, 1);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (6, '2024-06-22 09:00:00', '2024-06-22 09:07:00', '2024-06-22 09:08:00', '2024-06-22 09:38:00', 10, 6, 6, 6, 1);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (7, '2024-07-12 18:10:05', '2024-07-12 18:16:05', '2024-07-12 18:18:05', '2024-07-12 19:03:05', 8, 7, 4, 7, 2);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (8, '2024-08-27 22:05:30', '2024-08-27 22:15:30', '2024-08-27 22:18:30', '2024-08-27 22:48:30', 9, 8, 3, 8, 2);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (9, '2024-09-14 10:00:00', '2024-09-14 10:10:00', '2024-09-14 10:13:00', '2024-09-14 11:43:00', 6, 9, 2, 9, 3);
INSERT INTO `traslado` (`id_traslado`, `hora_pedido`, `hora_confirmacion`, `hora_salida`, `hora_llegada`, `id_vehiculo`, `id_origen`, `id_pasajero`, `id_conductor`, `id_tipo_transporte`) VALUES (10, '2024-10-30 21:45:15', '2024-10-30 21:55:15', '2024-10-30 21:58:15', '2024-10-30 23:58:15', 7, 10, 1, 10, 3);

COMMIT;


-- -----------------------------------------------------
-- Data for table `calificacion`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (1, 4.0, 4.1, 1);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (2, 4.2, 2.0, 2);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (3, 4.3, 4.2, 3);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (4, 4.0, 4.1, 4);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (5, 4.5, 4.3, 5);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (6, 4.8, 4.7, 6);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (7, 4.3, 4.2, 7);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (8, 4.7, 4.8, 8);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (9, 4.9, 5, 9);
INSERT INTO `calificacion` (`id_calificacion`, `calificacion_conductor`, `calificacion_viaje`, `id_traslado`) VALUES (10, 4.4, 4.3, 10);

COMMIT;


-- -----------------------------------------------------
-- Data for table `problema`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `problema` (`id_problema`, `descripcion`, `resuelto`, `id_traslado`) VALUES (1, 'se vomito el pasajero', 1, 2);

COMMIT;


-- -----------------------------------------------------
-- Data for table `ubicacion`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (1, -31.5297, 52.2731, '2024-01-15 8:40:00', 1, 10);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (2, -32.6391, 51.6739, '2024-02-20 14:45:00', 2, 9);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (3, -33.6391, 52.6739, '2024-03-05 19:20:00', 3, 8);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (4, -32.7391, 52.7739, '2024-04-10 12:30:00', 4, 7);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (5, -32.5391, 51.5739, '2024-05-18 16:46:00', 5, 6);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (6, -33.1391, 52.1739, '2024-06-22 9:16:00', 6, 5);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (7, -31.8391, 50.9739, '2024-07-12 18:24:00', 7, 4);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (8, -33.2391, 52.2739, '2024-08-27 22:23:00', 8, 3);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (9, -31.9391, 50.8739, '2024-09-14 10:20:00', 9, 2);
INSERT INTO `ubicacion` (`id_ubicacion`, `latitud`, `longitud`, `timestamp`, `id_traslado`, `id_pasajero`) VALUES (10, -32.4391, 51.4739, '2024-10-30 22:00:15', 10, 1);

COMMIT;


-- -----------------------------------------------------
-- Data for table `destino`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (1, 'Washington 325', '1785', 'CABA', 'Argentina', 0, 1);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (2, 'Vista hermosa 1430', '1557', 'CABA', 'Argentina', 0, 2);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (3, 'Av. Cabildo 2620', '1426', 'CABA', 'Argentina', 0, 3);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (4, 'Av. Santa Fe 3500', '1425', 'CABA', 'Argentina', 0, 4);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (5, 'Av. Pueyrredón 1500', '1118', 'CABA', 'Argentina', 0, 5);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (6, 'Av. Cabildo 2200', '1428', 'CABA', 'Argentina', 0, 6);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (7, 'Defensa 800', '1065', 'CABA', 'Argentina', 0, 7);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (8, 'Av. Triunvirato 5000', '1431', 'CABA', 'Argentina', 0, 8);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (9, 'Av. Rivadavia', '5200', 'CABA', 'Argentina', 0, 9);
INSERT INTO `destino` (`id_destino`, `direccion`, `codigo_postal`, `ciudad`, `pais`, `multidestino`, `id_traslado`) VALUES (10, 'Av. Corrientes', '4100', 'CABA', 'Argentina', 0, 10);

COMMIT;


-- -----------------------------------------------------
-- Data for table `pago`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (1, 'debito', 12552.23, 3, 1);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (2, 'credito', 10000.00, 2, 2);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (3, 'efectivo', 1526.30, 1, 3);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (4, 'efectivo', 4378.20, 4, 4);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (5, 'debito', 6732.00, 5, 5);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (6, 'efectivo', 2653.20, 6, 6);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (7, 'credito', 5988.10, 7, 7);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (8, 'debito', 3200.00, 8, 8);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (9, 'credito', 9000.50, 9, 9);
INSERT INTO `pago` (`id_pago`, `metodo`, `monto`, `id_pasajero`, `id_traslado`) VALUES (10, 'efectivo', 14250.20, 10, 10);

COMMIT;


-- -----------------------------------------------------
-- Data for table `costo_adicional`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `costo_adicional` (`id_costo_adicional`, `costo`, `especificacion`, `id_pago`) VALUES (1, 1000, 'Espera pasajero', 1);

COMMIT;


-- -----------------------------------------------------
-- Data for table `peaje`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `peaje` (`id_peaje`, `costo`, `id_traslado`) VALUES (1, 1500, 6);
INSERT INTO `peaje` (`id_peaje`, `costo`, `id_traslado`) VALUES (2, 2000, 10);
INSERT INTO `peaje` (`id_peaje`, `costo`, `id_traslado`) VALUES (3, 1500, 3);

COMMIT;


-- -----------------------------------------------------
-- Data for table `pais`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `pais` (`id_pais`, `nombre`, `capital`, `zona_horaria`) VALUES (1, 'Argentina', 'CABA', 'UTC -3');

COMMIT;


-- -----------------------------------------------------
-- Data for table `ciudad`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `ciudad` (`id_ciudad`, `nombre_ciudad`, `partido_localidad`, `id_pais`) VALUES (1, 'CABA', 'Ciudad Autonoma de Buenos Aires', 1);

COMMIT;


-- -----------------------------------------------------
-- Data for table `direccion_pasajero`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (1, 'Belgrano', 'Cabildo', '2233', '1A', 1, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (2, 'Flores', 'Rivadavia', '111', 'PB', 2, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (3, 'Palermo', 'Santa fe', '555', '', 3, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (4, 'Palermo', 'Oro', '214', '9D', 4, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (5, 'Villa Pueyrredon', 'Cabezon', '1472', '14C', 5, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (6, 'Once', 'Pueyrredon', '449', '1B', 6, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (7, 'Once', 'Lavalle', '895', '', 7, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (8, 'Flores', 'Bidegain', '1594', '2A', 8, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (9, 'La Boca', 'Maradona', '1010', '', 9, 1);
INSERT INTO `direccion_pasajero` (`id_direccion_pasajero`, `barrio`, `calle`, `numero`, `piso_depto`, `id_pasajero`, `id_ciudad`) VALUES (10, 'Las Cañitas', 'Abadia', '2020', '5B', 10, 1);

COMMIT;


-- -----------------------------------------------------
-- Data for table `ubicacion_ vehiculo`
-- -----------------------------------------------------
START TRANSACTION;
USE `TP2_G4`;
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (1, -34.6033, -58.3812, '2024-01-15 08:40:00', 1);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (2, -34.6158, -58.4434, '2024-02-20 15:00:00', 2);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (3, -34.6115, -58.3986, '2024-03-05 19:15:00', 3);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (4, -34.5892, -58.3801, '2024-04-10 12:30:00', 4);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (5, -34.5776, -58.4003, '2024-05-18 16:40:00', 5);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (6, -34.5748, -58.4914, '2024-06-22 09:40:00', 6);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (7, -34.6187, -58.4333, '2024-07-12 18:20:00', 7);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (8, -34.6076, -58.4204, '2024-08-27 22:20:00', 8);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (9, -34.6061, -58.5127, '2024-09-14 10:15:00', 9);
INSERT INTO `ubicacion_ vehiculo` (`id_ubicacion_ vehiculo`, `latitud`, `longitud`, `timestamp`, `id_vehiculo`) VALUES (10, -34.6372, -58.4567, '2024-10-30 22:00:00', 10);

COMMIT;


-- -----------------------------------------------------
--                      CONSULTAS
-- -----------------------------------------------------

-- 1) Hacer 1 SELECT * de una tabla
SELECT * FROM pasajero;

-- 2) Hacer 1 SELECT * de una tabla con ORDER BY
SELECT * FROM conductor ORDER BY apellido ASC;

-- 3) Hacer 1 SELECT * de una tabla con WHERE
SELECT * FROM destino WHERE direccion = 'Av. Santa Fe 3500';

-- 4) Hacer 1 SELECT * de una tabla con WHERE y ORDER BY
SELECT * FROM pasajero WHERE apellido LIKE 'M%' ORDER BY nombre DESC;

-- 5) Hacer 1 SELECT * de una tabla con COUNT
SELECT COUNT(*) as total_de_pasajeros FROM pasajero;

-- 6) Hacer 1 SELECT * de una tabla con COUNT
SELECT COUNT(*) as pago_mayor_a_10k FROM pago WHERE monto > 10000;

-- 7) Hacer 1 SELECT * de dos tablas unidas con JOIN
SELECT traslado.id_traslado, traslado.hora_pedido,
pasajero.nombre as nombre,
pasajero.apellido as apellido
FROM traslado
INNER JOIN pasajero on traslado.id_pasajero = pasajero.id_pasajero;

-- 8) Hacer 1 SELECT * de dos tablas unidas con JOIN

SELECT traslado.id_traslado, traslado.hora_confirmacion, pasajero.id_pasajero,
pasajero.nombre as nombre, 
pasajero.apellido as apellido, 
pago.monto as monto_pago,
pago.metodo as metodo
FROM traslado
INNER JOIN pasajero on traslado.id_pasajero = pasajero.id_pasajero
INNER JOIN pago on traslado.id_traslado = pago.id_traslado;

-- 9) Hacer 1 SELECT * de tres tablas unidas con JOIN y con WHERE

SELECT traslado.id_traslado, traslado.hora_pedido,
conductor.nombre as nombre_conductor,
pasajero.nombre as nombre_pasajero
FROM traslado
INNER JOIN pasajero on traslado.id_pasajero = pasajero.id_pasajero
INNER JOIN conductor on traslado.id_conductor = conductor.id_conductor
WHERE conductor.calificacion_promedio >= 4.2;

-- 10) Hacer 1 SELECT * de tres tablas unidas con JOIN, con COUNT y WHERE

SELECT 
conductor.nombre as nombre_conductor, 
conductor.calificacion_promedio as calificacion_promedio, 
vehiculo.marca,
COUNT(*) as total_traslados
FROM traslado
INNER JOIN vehiculo on traslado.id_vehiculo = vehiculo.id_vehiculo
INNER JOIN conductor on traslado.id_conductor = conductor.id_conductor
WHERE conductor.calificacion_promedio >= 4.0
GROUP BY conductor.id_conductor, conductor.nombre, conductor.calificacion_promedio, vehiculo.marca;
