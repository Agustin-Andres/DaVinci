<?php

    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];
    $correElectronico = $_POST["correoElectronico"];
    $usuario = $_POST["usuario"];
    $clave = $_POST["clave"];

     var_dump($nombre, $apellido, $correElectronico, $usuario, $clave);

?>