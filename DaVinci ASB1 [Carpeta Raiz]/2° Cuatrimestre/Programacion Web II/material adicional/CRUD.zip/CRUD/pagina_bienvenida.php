<?php

    session_start();

    echo "<h1>Bienvenido {$_SESSION["usuario"]} </h1>";

    echo "<a href='cerrar_sesion.php'>Cerrar Sesión</a>";

 ?>