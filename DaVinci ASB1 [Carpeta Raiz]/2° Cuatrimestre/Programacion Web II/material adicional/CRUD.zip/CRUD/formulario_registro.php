<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Registro</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .links {
            display: flex;
            justify-content: flex-start;
            gap: 10px; /* Reducir la separación entre los enlaces */
            font-size: 0.875rem; /* Tamaño de fuente más pequeño (14px aprox.) */
        }
        .form-container {
            max-width: 600px; /* Limitar el ancho del formulario en pantallas grandes */
            margin: 0 auto;
        }
        .button-space {
            margin-top: 20px; /* Espacio más grande entre el botón "Enviar" y los enlaces */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <h2 class="mb-4">Registro</h2>
        <form method="POST" action="registrar_datos.php">
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control form-control-sm" id="nombre" name="nombre" placeholder="Ingrese su nombre" value="Lisa">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="apellido" class="form-label">Apellido</label>
                    <input type="text" class="form-control form-control-sm" id="apellido" name="apellido" placeholder="Ingrese su apellido" value="Simpson">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="correoElectronico" class="form-label">Correo Electrónico</label>
                    <input type="email" class="form-control form-control-sm" id="correoElectronico" name="correoElectronico" placeholder="Ingrese su correo electrónico" value="lsimpson@dominio.com">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="usuario" class="form-label">Usuario</label>
                    <input type="text" class="form-control form-control-sm" id="usuario" name="usuario" placeholder="Ingrese su usuario" value="lsimpson">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="clave" class="form-label">Clave</label>
                    <input type="password" class="form-control form-control-sm" id="clave" name="clave" placeholder="Ingrese su clave" value="123456">
                </div>
            </div>
            <div class="mb-3 button-space">
                <button type="submit" class="btn btn-primary btn-sm">Enviar</button>
            </div>
        </form>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>