<?php

    session_start();  // Inicia o reanuda la sesión

    $usuario = $_POST["usuario"];  // Captura el nombre de usuario ingresado en el formulario
    $clave = $_POST["clave"];      // Captura la clave ingresada en el formulario

    // Verifica si el usuario y la clave coinciden con "bsimpson" y "123456"
    if($usuario == "bsimpson" && $clave == "123456"){

        // Guarda el usuario en la sesión para futuras páginas
        $_SESSION["usuario"] = $usuario;

        // Redirige al usuario a la página de bienvenida
        header("Location: pagina_bienvenida.php");
    }
    else{
        // Si el usuario o la clave no coinciden, muestra un mensaje de error
        echo 'Usuario y/o clave inválido.';
    }

?>

