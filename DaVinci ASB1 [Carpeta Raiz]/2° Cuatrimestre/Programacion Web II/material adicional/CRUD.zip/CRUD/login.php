<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .links {
            display: flex;
            justify-content: flex-start;
            gap: 10px; /* Reducir la separación entre los enlaces */
            font-size: 0.875rem; /* Tamaño de fuente más pequeño (14px aprox.) */
        }
        .form-container {
            max-width: 600px;
            margin: 0 auto;
        }
        .button-space {
            margin-top: 20px; /* Espacio más grande entre el botón "Ingresar" y los enlaces */
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="form-container">
        <h2 class="mb-4">Login</h2>
        <form method="POST" action="validar_datos.php">
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="usuario" class="form-label">Usuario</label>
                    <input type="text" class="form-control form-control-sm" id="usuario" name="usuario" placeholder="Ingrese su usuario" value="bsimpson">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-8">
                    <label for="clave" class="form-label">Clave</label>
                    <input type="password" class="form-control form-control-sm" id="clave" name="clave" placeholder="Ingrese su clave" value="123456">
                </div>
            </div>
            <div class="mb-3 button-space">
                <button type="submit" class="btn btn-primary btn-sm">Ingresar</button>
            </div>
            <div class="mb-3 links">
                <a href="registrar_datos.php" class="text-decoration-none">¿Olvidó su Clave?</a>
                <a href="formulario_registro.php" class="text-decoration-none">Registrarse</a>
            </div>
        </form>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


