import sistemaGaraje.GarajeTest;

public class App {
    public static void main(String[] args) throws Exception {
        GarajeTest.iniciarSession();
    }
}

