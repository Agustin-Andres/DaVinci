import interfaz.InterfazPrincipal;

public class Main {
    public static void main(String[] args) throws Exception {
        InterfazPrincipal.menuInicial();
    }
}
