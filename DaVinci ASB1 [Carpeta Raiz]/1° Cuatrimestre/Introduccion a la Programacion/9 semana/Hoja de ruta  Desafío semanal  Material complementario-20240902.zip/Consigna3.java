
public class Consigna3 {
    public static void main(String[] args) {
        int[] array = new int[10];
        int count = 0;

        while (count < 10) {
            int randomNumber = (int)(Math.random() * 25)  + 1; // Genera un número entre 1 y 25
            boolean exists = false; // flag - barrera

            // Verifica si el número ya está en el array
            for (int i = 0; i < count; i++) {
                if (array[i] == randomNumber) {
                    // ya existe el nro
                    exists = true;
                    break;
                }
            }

            // Si el número no está en el array, lo agrega
            if (!exists) {
                array[count] = randomNumber;
                count++;
            }
        }

        // Imprimir el array
        for (int number : array) {
            System.out.print(number + " ");
        }
    }
}
