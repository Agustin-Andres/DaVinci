package clase_20240417;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Cuestionario {
    public static void main(String[] args) throws Exception {
        // Cuestionario:
        // Armar las 4 preguntas con opciones
        // Contar la cantidad de respuestas correctas

        int respuestasCorrectas = 0; // contador

        // armar la pregunta numero 1 con las opciones
        String respuesta1 = (String) JOptionPane.showInputDialog(
                null,
                "¿De que país es la bandera? \na) Brunei \nb) Argentina\nc) Trinidad y tobago",
                "Pregunta 1",
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Cuestionario.class.getResource("img/brunei.png")),
                null, null);
        if (respuesta1.equalsIgnoreCase("a")) {
            respuestasCorrectas++; // +1
            JOptionPane.showMessageDialog(null, "Respuesta correcta.");
        } else {
            // la pifiaste
            JOptionPane.showMessageDialog(null, "Respuesta incorrecta.");
        }

        // armar la pregunta numero 2 con las opciones
        String respuesta2 = (String) JOptionPane.showInputDialog(
                null,
                "¿De que país es la bandera? \na) islandia \nb) Brasil\nc) Trinidad y tobago",
                "Pregunta 1",
                JOptionPane.INFORMATION_MESSAGE,
                new ImageIcon(Cuestionario.class.getResource("img/islandia.jpg")),
                null, null);
        if (respuesta1.equalsIgnoreCase("a")) {
            respuestasCorrectas++; // +1
            JOptionPane.showMessageDialog(null, "Respuesta correcta.");
        } else {
            // la pifiaste
            JOptionPane.showMessageDialog(null, "Respuesta incorrecta.");
        }

        JOptionPane.showMessageDialog(
                null, "Cantidad de respuestas correctas: " + respuestasCorrectas);

    }
}
