package clase_20240417;

import java.util.Scanner;

public class Ternario {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        // Ingresar la edad y mostrar si es mayor o menor
        System.out.println("Ingrese la edad: ");
        int edad = sc.nextInt();

        // Ternario: if y else
        // String mensaje = (edad >= 18) ? "Sos mayor de edad" : "Sos menor de edad"; //
        // Condicional ternario

        // Ternario if, else if y else
        // sos mayor, si sos jubilado sino sos menor
        String msj = (edad >= 18 && edad < 65) ? "Sos mayor de edad" : (edad >= 65) ? "Sos jubilado" : "Sos menor.";

        System.out.println(msj);

        sc.close();
    }
}
