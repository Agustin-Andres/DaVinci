package clase_20240424;

import java.util.Scanner;

public class Cajero {
    public static final int CONTRASENA = 1234;

    public static void main(String[] args) {
        // Intentos de inicio de sesión
        int intentosRestantes = 3;

        // Bucle para la validación de la credencial (3 intentos)
        intentosRestantes = ProcesarSistemaCajero(intentosRestantes);

        // Si se terminaron los intentos, mostrar el bloqueo de la cuenta
        MostrarMensajeSinIntentos(intentosRestantes);
    }

    public static void MostrarMensajeSinIntentos(int intentos) {
        if (intentos == 0) {
            System.out.println("Se han agotado los intentos. La cuenta está bloqueada.");
        }
    }

    public static int ProcesarSistemaCajero(int intentosRestantes) {
        Scanner scanner = new Scanner(System.in);

        // Establecer la contrasena y el saldo inicial
        double saldoDisponible = 1000;
        boolean continuarPrograma = true;

        while (intentosRestantes > 0) {
            // Solicitar la contrasena al usuario
            System.out.println("Ingrese su contrasena:");
            int contrasenaIngresada = scanner.nextInt();

            // Verificar si la contrasena es válida
            if (ValidarContrasena(contrasenaIngresada)) {
                System.out.println("contrasena válida.");
                while (continuarPrograma) { // SOLUCIONAR BUG, PENSAR EN QUE SOLUCION APLICAR
                    // Mostrar opciones al usuario
                    MenuOpciones();

                    // Leer la opción elegida por el usuario
                    int opcion = scanner.nextInt();

                    // Procesar la opción elegida
                    switch (opcion) {
                        case 1:
                            // Mostrar saldo disponible en la cuenta
                            MostrarSaldoDisponible(saldoDisponible);
                            break;
                        case 2:
                            // Consultar al usuario cuanto dinero desea extraer
                            saldoDisponible = ExtraerDinero(scanner, saldoDisponible);
                            break;
                        case 3:
                            System.out.println("Saliendo del sistema.");
                            // flag: terminamos el programa
                            continuarPrograma = false;
                            break; // Salir del bucle
                        default:
                            System.out.println("Opción inválida. Por favor ingrese una opción válida.");
                    }
                }

                // salir del bucle de inicio si el usuario cierra el programa con la opcion 3
                break;
            } else {
                // Restar al contador de intentos y mostrar la cantidad de intentos restantes
                intentosRestantes--;
                System.out.println("contrasena incorrecta. Intentos restantes: " + intentosRestantes);
            }

            scanner.close();
        }

        return intentosRestantes;
    }

    public static void MenuOpciones() {
        System.out.println("Opciones:\n1. Consultar saldo disponible\n2. Extracción\n3. Salir");
    }

    public static void MostrarSaldoDisponible(double saldo) {
        System.out.println(String.format("Saldo disponible: %.2f", saldo));
    }

    public static double ExtraerDinero(Scanner scanner, double saldoDisponible) {
        System.out.println("Ingrese la cantidad de dinero que desea extraer:");
        double cantidadRetirar = scanner.nextDouble();

        // Validar si el dinero que quiere extraer es <= al que tiene disponible
        if (cantidadRetirar <= saldoDisponible) {
            // Realizar el cálculo de extracción y mostrar el saldo que queda
            saldoDisponible -= cantidadRetirar;
            System.out.println("Extracción exitosa. \n");
            MostrarSaldoDisponible(saldoDisponible);
        } else {
            System.out.println("Monto superior a su saldo. Ingrese nuevamente un saldo.");
        }

        return saldoDisponible;
    }

    public static boolean ValidarContrasena(int contrasenaIngresada) {
        boolean validar = (contrasenaIngresada == CONTRASENA);
        return validar;
    }
}
