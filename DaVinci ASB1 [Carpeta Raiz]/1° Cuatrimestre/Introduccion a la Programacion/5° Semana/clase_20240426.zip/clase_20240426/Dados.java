package clase_20240426;

import java.util.Scanner;

public class Dados {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // Crear un sistema que permita al usuario adivinar el número de un dado. (con
        // tres intentos)

        // Generar un numero aleatorio entre 1 y 6
        int numeroAleatorio = (int) (Math.random() * 6) + 1; // 1 - 6

        // 3 intentos
        /*
         * int intentos = 3; // contador
         * System.out.println("Bienvenido al juego, tienes " + intentos + " intentos.");
         * while (intentos > 0) {
         * System.out.println("Ingrese su prediccion (1-6): ");
         * while (!sc.hasNextInt()) { // validacion es por si el usuario NO ingresa un
         * INT
         * System.out.println("Por favor, ingrese un número valido.");
         * sc.next(); // limpiar
         * }
         * int prediccion = sc.nextInt();
         * 
         * // validar si ingresa un numero entre 1 y 6, [1:6]
         * if (prediccion >= 1 && prediccion <= 6) { // prediccion > 0 && prediccion < 7
         * // Aplicar la adivinanza
         * if (prediccion == numeroAleatorio) {
         * System.out.println("FELICIDADES, HAS GANADO");
         * break;
         * } else {
         * intentos--; // intentos = intentos - 1; intentos -= 1;
         * System.out.println("INCORRECTO, INTENTELO DE NUEVO. LE QUEDAN " + intentos +
         * " INTENTOS.");
         * }
         * } else {
         * System.out.println("Por favor ingrese un numero entre 1 y 6.");
         * }
         * }
         * if (intentos == 0) {
         * System.out.println("Termino el juego, has agotado los intentos.");
         * }
         */

        // flag
        boolean mostrarMensaje = false;
        System.out.println(numeroAleatorio);
        for (int i = 2; i >= 0; i--) {
            System.out.println("Ingrese su prediccion (1-6): ");
            while (!sc.hasNextInt()) { // validacion es por si el usuario NO ingresa un INT
                System.out.println("Por favor, ingrese un número valido.");
                sc.next(); // limpiar
            }
            int prediccion = sc.nextInt();

            // validar si ingresa un numero entre 1 y 6, [1:6]
            if (prediccion >= 1 && prediccion <= 6) { // prediccion > 0 && prediccion < 7
                // Aplicar la adivinanza
                if (prediccion == numeroAleatorio) {
                    System.out.println("FELICIDADES, HAS GANADO");
                    break;
                } else {
                    // opcion 1 - for (int i = 3; i > 0; i--)
                    // intentos--;
                    // System.out.println("INCORRECTO, INTENTELO DE NUEVO. LE QUEDAN " + intentos +
                    // " INTENTOS.");
                    // opcion 2 - for (int i = 3; i > 0; i--)
                    // System.out.println("INCORRECTO, INTENTELO DE NUEVO. LE QUEDAN " + (--i) + "
                    // INTENTOS.");
                    // opcion 3 - for (int i = 2; i >= 0; i--)
                    System.out.println("INCORRECTO, INTENTELO DE NUEVO. LE QUEDAN " + i + " INTENTOS.");
                }
                // ternario para cambiar el booleano y mostrar el valor
                mostrarMensaje = (i == 0) ? true : false;
            } else {
                System.out.println("Por favor ingrese un numero entre 1 y 6.");
            }
        }

        if (mostrarMensaje) {
            System.out.println("Termino el juego, has agotado los intentos.");
        }

        sc.close();
    }
}
