		-WireFrame

-Por la consigna del trabajo practico, dejo las imagenes del mock up de la pagina, en teoria se va a ver tal cual indican las paginas al final del trabajo practicto.

##Notar que puede cambiar a lo largo del proceso del TP, por mejores practicas, comodidad, etc.

	- Agustin Andres Avellaneda

