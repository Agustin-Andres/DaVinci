		- TP_HTML&CSS_(Parte_1) - 

- Este es el primer trabajo practico que tenemos que realizar, tendra una carpeta raiz donde se creara, manipulara, actualizara todo dentro del tp.

Por motivos de aprendizaje, la pagina estara en español pero los documentos, codigos, nombres de identificadores y carpetas estaran en ingles. 

Ejemplo de directorio: 
- carpeta-raiz
  - index.html
  - css[carpeta]
  - images[carpeta]
  - pages [carpeta]
    - about.html
    - services.html
    - products.html
    - contact.html
    - more-info.html




### Por favor notar que puede cambiar debido a mejores practicas o comodidad en administracion de los elementos utilizados.

-Agustin Andres Avellaneda


